<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-30 03:40:33 --> Query error: Table 'ikn.us_identifications' doesn't exist - Invalid query: SELECT `usid_id` AS `id`, `usid_name` AS `name`, `status` AS `status`
FROM `us_identifications`
ORDER BY `uspr_name`
ERROR - 2020-05-30 03:43:16 --> Query error: Unknown column 'uspr_name' in 'order clause' - Invalid query: SELECT `usid_id` AS `id`, `usid_name` AS `name`, `status` AS `status`
FROM `us_identifications`
ORDER BY `uspr_name`
ERROR - 2020-05-30 04:16:50 --> Severity: Notice --> Undefined index: METHOD_NOT_ALLOWED C:\xampp\htdocs\api\application\libraries\RestController.php 551
